const contenus = {
  1: {
    texte: "Trouve l’arbre avec la marque rouge.",
    image: "https://via.placeholder.com/600x400/ff6666/fff?text=Balise+1",
    video: "",
    audio: ""
  },
  2: {
    texte: "Regarde près de la fontaine.",
    image: "https://via.placeholder.com/600x400/66ccff/fff?text=Balise+2",
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    audio: ""
  },
  3: {
    texte: "Écoute le son de la rivière pour te guider.",
    image: "",
    video: "",
    audio: "https://www.w3schools.com/html/horse.mp3"
  },
  4: {
    texte: "Trouve la pierre plate au milieu du champ.",
    image: "https://via.placeholder.com/600x400/cccccc/000?text=Balise+4",
    video: "",
    audio: ""
  },
  5: {
    texte: "Suivez le sentier jusqu’au vieux chêne.",
    image: "https://via.placeholder.com/600x400/228B22/fff?text=Balise+5",
    video: "",
    audio: ""
  },
  // Tu peux remplir les autres jusqu'à 25 comme tu veux
};